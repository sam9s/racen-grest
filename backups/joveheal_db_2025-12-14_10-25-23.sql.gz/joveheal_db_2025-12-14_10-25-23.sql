--
-- PostgreSQL database dump
--

\restrict VRJB0ZGhwwBnVhE5UWr9H2J1AVYjpeABV7oj7qeTixoKcEkN57ttTK5Tf7sccp3

-- Dumped from database version 16.11 (b740647)
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_user_id_fkey;
DROP INDEX IF EXISTS public.ix_user_accounts_external_id;
DROP INDEX IF EXISTS public.ix_user_accounts_email;
DROP INDEX IF EXISTS public.ix_user_accounts_channel;
DROP INDEX IF EXISTS public.ix_response_feedback_id;
DROP INDEX IF EXISTS public.ix_conversations_timestamp;
DROP INDEX IF EXISTS public.ix_conversations_session_id;
DROP INDEX IF EXISTS public.ix_conversations_safety_flagged;
DROP INDEX IF EXISTS public.ix_conversations_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_user_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_session_id;
DROP INDEX IF EXISTS public.ix_chat_sessions_id;
DROP INDEX IF EXISTS public.ix_analytics_daily_id;
DROP INDEX IF EXISTS public.ix_analytics_daily_date;
DROP INDEX IF EXISTS public.idx_conversation_summaries_user_id;
ALTER TABLE IF EXISTS ONLY public.user_accounts DROP CONSTRAINT IF EXISTS user_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.user_accounts DROP CONSTRAINT IF EXISTS uq_channel_external_id;
ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.response_feedback DROP CONSTRAINT IF EXISTS response_feedback_conversation_id_key;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_user_id_key;
ALTER TABLE IF EXISTS ONLY public.conversation_summaries DROP CONSTRAINT IF EXISTS conversation_summaries_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_daily DROP CONSTRAINT IF EXISTS analytics_daily_pkey;
ALTER TABLE IF EXISTS public.user_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.response_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conversation_summaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.analytics_daily ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.user_accounts_id_seq;
DROP TABLE IF EXISTS public.user_accounts;
DROP SEQUENCE IF EXISTS public.response_feedback_id_seq;
DROP TABLE IF EXISTS public.response_feedback;
DROP SEQUENCE IF EXISTS public.conversations_id_seq;
DROP TABLE IF EXISTS public.conversations;
DROP SEQUENCE IF EXISTS public.conversation_summaries_id_seq;
DROP TABLE IF EXISTS public.conversation_summaries;
DROP SEQUENCE IF EXISTS public.chat_sessions_id_seq;
DROP TABLE IF EXISTS public.chat_sessions;
DROP SEQUENCE IF EXISTS public.analytics_daily_id_seq;
DROP TABLE IF EXISTS public.analytics_daily;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_daily (
    id integer NOT NULL,
    date timestamp without time zone,
    total_conversations integer,
    unique_sessions integer,
    safety_flags integer,
    avg_response_time_ms double precision,
    positive_feedback integer,
    negative_feedback integer
);


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analytics_daily_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analytics_daily_id_seq OWNED BY public.analytics_daily.id;


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id integer NOT NULL,
    session_id character varying(100) NOT NULL,
    created_at timestamp without time zone,
    last_activity timestamp without time zone,
    channel character varying(50),
    user_id integer
);


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_sessions_id_seq OWNED BY public.chat_sessions.id;


--
-- Name: conversation_summaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_summaries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    emotional_themes text,
    recommended_programs text,
    last_topics text,
    conversation_status text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_summaries_id_seq OWNED BY public.conversation_summaries.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    session_id character varying(100),
    "timestamp" timestamp without time zone,
    user_question text NOT NULL,
    bot_answer text NOT NULL,
    safety_flagged boolean,
    safety_category character varying(100),
    sources_used text,
    response_time_ms integer
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: response_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.response_feedback (
    id integer NOT NULL,
    conversation_id integer,
    rating integer NOT NULL,
    comment text,
    created_at timestamp without time zone
);


--
-- Name: response_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.response_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: response_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.response_feedback_id_seq OWNED BY public.response_feedback.id;


--
-- Name: user_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_accounts (
    id integer NOT NULL,
    channel character varying(50) NOT NULL,
    external_id character varying(255) NOT NULL,
    email character varying(255),
    display_name character varying(255),
    profile_image character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_accounts_id_seq OWNED BY public.user_accounts.id;


--
-- Name: analytics_daily id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily ALTER COLUMN id SET DEFAULT nextval('public.analytics_daily_id_seq'::regclass);


--
-- Name: chat_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.chat_sessions_id_seq'::regclass);


--
-- Name: conversation_summaries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries ALTER COLUMN id SET DEFAULT nextval('public.conversation_summaries_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: response_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback ALTER COLUMN id SET DEFAULT nextval('public.response_feedback_id_seq'::regclass);


--
-- Name: user_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts ALTER COLUMN id SET DEFAULT nextval('public.user_accounts_id_seq'::regclass);


--
-- Data for Name: analytics_daily; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_daily (id, date, total_conversations, unique_sessions, safety_flags, avg_response_time_ms, positive_feedback, negative_feedback) FROM stdin;
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, session_id, created_at, last_activity, channel, user_id) FROM stdin;
1	4899da78-0435-4830-a33a-55b9a91f0241	2025-12-01 08:03:57.637656	2025-12-01 08:03:57.637661	web	\N
2	api_test_test123_20251201081612	2025-12-01 08:16:16.880357	2025-12-01 08:16:16.880368	api_test	\N
3	api_test_test_user_20251201082053	2025-12-01 08:21:00.398881	2025-12-01 08:21:09.236373	api_test	\N
4	410377dd-2d3b-48d6-9a91-6a40556b30a1	2025-12-01 08:27:59.115906	2025-12-01 08:27:59.115911	web	\N
36	widget_1765437473959_j1h9txyv1	2025-12-11 07:18:24.021006	2025-12-11 07:19:33.299518	web	\N
5	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:33:55.215563	2025-12-01 09:43:39.896307	web	\N
6	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:15.534748	2025-12-01 09:58:54.132359	web	\N
7	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:05:37.356767	2025-12-01 10:07:46.648509	web	\N
8	eed23f1c-3d2e-4388-8078-a65d690c4f94	2025-12-01 10:24:47.581072	2025-12-01 10:24:47.581077	web	\N
9	860cab47-d476-44dc-af24-f3dda296dcc6	2025-12-01 11:03:38.128583	2025-12-01 11:03:38.128589	web	\N
10	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:31:51.270514	2025-12-01 11:33:30.613827	web	\N
11	user_sammy_test	2025-12-04 05:57:18.117433	2025-12-04 05:57:21.517687	web	2
12	user_sammy_new_session	2025-12-04 05:57:48.317146	2025-12-04 05:57:50.712431	web	2
13	guest_1764828759834_sw15y6o92	2025-12-04 06:13:57.013803	2025-12-04 06:14:17.218976	web	\N
14	test_shed_shine	2025-12-04 06:22:56.980015	2025-12-04 06:23:00.363407	web	\N
15	user_sammy@test.com	2025-12-04 07:34:48.839801	2025-12-04 07:34:51.741275	web	2
16	user_newuser@example.com	2025-12-04 07:35:04.045349	2025-12-04 07:35:06.483148	web	3
17	guest_1764833832077_yp756jiqr	2025-12-04 07:37:21.212577	2025-12-04 07:37:42.348515	web	\N
37	guest_1765437466934_bpzixcb5n	2025-12-11 07:19:22.766306	2025-12-11 07:21:58.005284	web	\N
18	user_test@summary.com	2025-12-04 07:53:18.826703	2025-12-04 07:54:01.616512	web	4
19	user_test@summary.com_new_session	2025-12-04 07:54:27.424807	2025-12-04 07:54:31.946787	web	4
20	user_test@summary.com_session2	2025-12-04 07:55:25.912271	2025-12-04 07:55:29.529123	web	4
21	user_test@summary.com_session3	2025-12-04 07:56:18.275274	2025-12-04 07:56:21.78469	web	4
22	user_test@summary.com_session4	2025-12-04 07:57:19.242471	2025-12-04 07:57:22.235995	web	4
23	user_test@summary.com_session5	2025-12-04 07:58:06.508994	2025-12-04 07:58:10.860553	web	4
24	user_test@summary.com_session6	2025-12-04 07:59:12.626003	2025-12-04 07:59:17.282743	web	4
25	test_123	2025-12-04 11:25:34.165165	2025-12-04 11:25:34.16517	web	\N
26	test_456	2025-12-04 11:26:50.976058	2025-12-04 11:26:52.797945	web	\N
27	test_789	2025-12-04 11:27:02.814055	2025-12-04 11:27:05.509923	web	\N
38	guest_1765438454208_nejh7kjn5	2025-12-11 07:34:20.422211	2025-12-11 07:34:24.38333	web	\N
28	manychat_insta_12345	2025-12-10 03:41:57.097113	2025-12-10 03:43:51.374179	instagram	\N
29	manychat_test123	2025-12-10 04:11:15.374622	2025-12-10 04:11:16.940096	instagram	\N
30	widget_1765353094047_v5ueg562z	2025-12-10 07:52:00.907655	2025-12-10 07:52:06.180847	web	\N
31	widget_1765353332794_h56duugt7	2025-12-10 07:56:02.846998	2025-12-10 07:56:06.969576	web	\N
32	guest_1765360643640_nl7idovap	2025-12-10 09:57:49.577917	2025-12-10 09:57:52.663927	web	\N
33	guest_1765436537649_mp6r1efp3	2025-12-11 07:03:11.337986	2025-12-11 07:03:18.538454	web	\N
34	guest_1765436789488_tqadnrc3c	2025-12-11 07:10:51.678354	2025-12-11 07:14:28.687653	web	\N
35	widget_1765437289627_ttdtyw4pj	2025-12-11 07:15:22.98306	2025-12-11 07:15:30.382417	web	\N
64	guest_1765533455804_7dcg8qc39	2025-12-12 09:57:43.583286	2025-12-12 09:58:15.272493	web	\N
53	stress_test_11	2025-12-11 10:15:06.655251	2025-12-11 10:29:56.374411	web	\N
51	stress_test_12	2025-12-11 10:15:06.47544	2025-12-11 10:29:59.327235	web	\N
39	guest_1765438484407_96s7qm87l	2025-12-11 07:34:48.20375	2025-12-11 07:37:56.618678	web	\N
52	stress_test_13	2025-12-11 10:15:06.579937	2025-12-11 10:30:00.139352	web	\N
54	stress_test_10	2025-12-11 10:15:06.92079	2025-12-11 10:30:00.432475	web	\N
50	stress_test_14	2025-12-11 10:15:06.466505	2025-12-11 10:30:00.90392	web	\N
65	guest_1765548645708_fhwunxsga	2025-12-12 14:11:41.557519	2025-12-12 14:17:01.088214	web	\N
56	stress_test_16	2025-12-11 10:15:23.690444	2025-12-11 10:30:07.260024	web	\N
59	stress_test_19	2025-12-11 10:15:24.200966	2025-12-11 10:30:08.998202	web	\N
66	guest_1765603737321_wg66dx7ww	2025-12-13 05:29:29.60087	2025-12-13 05:32:47.027072	web	\N
55	stress_test_15	2025-12-11 10:15:23.372342	2025-12-11 10:30:09.151734	web	\N
42	stress_test_0	2025-12-11 10:14:38.756634	2025-12-11 10:29:36.414254	web	\N
40	stress_test_1	2025-12-11 10:14:38.754334	2025-12-11 10:29:39.523601	web	\N
44	stress_test_2	2025-12-11 10:14:38.755241	2025-12-11 10:29:40.836578	web	\N
41	stress_test_3	2025-12-11 10:14:38.756093	2025-12-11 10:29:40.895342	web	\N
43	stress_test_4	2025-12-11 10:14:38.753187	2025-12-11 10:29:40.999254	web	\N
57	stress_test_18	2025-12-11 10:15:23.749971	2025-12-11 10:30:12.046872	web	\N
58	stress_test_17	2025-12-11 10:15:24.003649	2025-12-11 10:30:13.203155	web	\N
60	guest_1765451865245_ikr5yipxx	2025-12-11 11:17:56.720125	2025-12-11 11:18:05.659976	web	\N
48	stress_test_5	2025-12-11 10:14:49.400872	2025-12-11 10:29:45.811209	web	\N
46	stress_test_7	2025-12-11 10:14:49.094651	2025-12-11 10:29:48.218762	web	\N
45	stress_test_6	2025-12-11 10:14:49.027902	2025-12-11 10:29:49.305248	web	\N
47	stress_test_9	2025-12-11 10:14:49.242444	2025-12-11 10:29:49.383688	web	\N
49	stress_test_8	2025-12-11 10:14:49.486074	2025-12-11 10:29:51.642289	web	\N
67	guest_1765604634749_atl3y5g12	2025-12-13 05:43:58.885541	2025-12-13 05:44:00.7381	web	\N
63	guest_1765532526825_0o345z1jq	2025-12-12 09:42:33.660191	2025-12-12 09:46:33.694243	web	\N
61	guest_1765521802876_1s9jl0uvd	2025-12-12 06:43:30.58465	2025-12-12 06:43:41.875754	web	\N
62	guest_1765521493208_968l2s3y4	2025-12-12 07:18:47.242867	2025-12-12 07:19:00.193809	web	\N
\.


--
-- Data for Name: conversation_summaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_summaries (id, user_id, emotional_themes, recommended_programs, last_topics, conversation_status, updated_at) FROM stdin;
1	4	["feeling disconnected from society", "stressed about career"]	["Beyond the Hustle"]	The user greeted the assistant multiple times, and the assistant acknowledged the user's previous feelings of disconnection and stress while suggesting a program for further exploration.	"exploring programs"	2025-12-04 07:59:19.244676
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, session_id, "timestamp", user_question, bot_answer, safety_flagged, safety_category, sources_used, response_time_ms) FROM stdin;
1	4899da78-0435-4830-a33a-55b9a91f0241	2025-12-01 08:03:57.409036	What services does JoveHeal offer?	JoveHeal offers a variety of wellness coaching services aimed at personal transformation and holistic well-being. Here are the main services we provide:\n\n1. **Balance Mastery+ Program**: \n   - A signature coaching experience designed to help you develop clarity about life goals, build sustainable routines, and master your mindset.\n\n2. **Inner Mastery Lounge**:\n   - An exclusive membership community that includes weekly group coaching sessions, access to guided meditations and exercises, community support, and monthly masterclasses on personal development.\n\n3. **Healing Sessions**:\n   - Available in both individual and group formats, these sessions focus on energy alignment, stress relief, emotional release, and mindfulness practices.\n\n4. **Workshops**:\n   - Regular workshops on topics like goal setting, mindset transformation, stress management, and confidence building, available both in-person and online.\n\nFeel free to reach out if you have more specific questions about any of these services!	f	\N	["joveheal_sample.txt"]	\N
2	api_test_test123_20251201081612	2025-12-01 08:16:15.749417	What programs does JoveHeal offer?	JoveHeal offers several programs and services, including:\n\n1. **Balance Mastery+ Program**: This is the signature coaching experience designed to help individuals develop clarity about their life goals, build sustainable daily routines, master their mindset, create work-life balance, and develop confidence and self-leadership skills. The program typically runs for 8-12 weeks.\n\n2. **Inner Mastery Lounge**: This is an exclusive membership community that includes weekly group coaching sessions, access to guided meditations and exercises, community support, monthly masterclasses on personal development topics, and exclusive resources for members.\n\nAdditionally, JoveHeal offers individual and group healing sessions focused on energy alignment, stress relief, emotional release, and mindfulness practices. Regular workshops on topics such as goal setting, mindset transformation, and self-care are also available.\n\nFor more information about joining any of these programs, you can visit their website at www.joveheal.com.	f	\N	["joveheal_sample.txt"]	\N
3	api_test_test_user_20251201082053	2025-12-01 08:20:57.046012	What is Balance Mastery?	The Balance Mastery+ program is JoveHeal's signature coaching experience designed to help individuals achieve personal transformation and clarity. This program focuses on several key areas, including:\n\n- Developing clarity about your life goals and direction\n- Building sustainable daily routines for success\n- Mastering your mindset and overcoming limiting beliefs\n- Creating a work-life balance that truly works\n- Developing confidence and self-leadership skills\n\nThe program typically runs for 8-12 weeks and provides personalized guidance and support to help participants unlock their potential and create lasting positive change in their lives. If you're interested in this program, I recommend visiting the JoveHeal website for more details.	f	\N	["joveheal_sample.txt"]	\N
4	api_test_test_user_20251201082053	2025-12-01 08:21:09.043818	What is Balance Mastery?	The Balance Mastery+ program is JoveHeal's signature coaching experience aimed at helping individuals achieve personal transformation and clarity. Key focuses of this program include:\n\n- Developing clarity about life goals and direction\n- Building sustainable daily routines for success\n- Mastering mindset and overcoming limiting beliefs\n- Creating effective work-life balance\n- Developing confidence and self-leadership skills\n\nTypically, the program runs for 8-12 weeks and offers personalized guidance and support. For more information, you can check the JoveHeal website.	f	\N	["joveheal_sample.txt"]	\N
5	410377dd-2d3b-48d6-9a91-6a40556b30a1	2025-12-01 08:27:58.896119	What programs does JoveHeal offer?	JoveHeal offers several programs focused on wellness coaching and personal transformation:\n\n1. **Balance Mastery+ Program**: This is our signature coaching experience designed to help you:\n   - Develop clarity about your life goals and direction\n   - Build sustainable daily routines for success\n   - Master your mindset and overcome limiting beliefs\n   - Create work-life balance that actually works\n   - Develop confidence and self-leadership skills\n\n2. **Inner Mastery Lounge**: This is an exclusive membership community that includes:\n   - Weekly group coaching sessions\n   - Access to guided meditations and exercises\n   - Community support and networking\n   - Monthly masterclasses on personal development topics\n   - Exclusive resources and tools for members\n\nWe also offer healing sessions, both individual and group, focusing on energy alignment, stress relief, and mindfulness practices.\n\nIf you have more specific questions about these programs or how to get started, feel free to ask!	f	\N	["joveheal_sample.txt"]	\N
6	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:33:54.99065	hi what programms yo uoffer?	At JoveHeal, we offer several programs designed to support your wellness journey:\n\n1. **Balance Mastery+ Program**: This is our signature coaching experience that helps you:\n   - Develop clarity about your life goals and direction\n   - Build sustainable daily routines for success\n   - Master your mindset and overcome limiting beliefs\n   - Create work-life balance that actually works\n   - Develop confidence and self-leadership skills\n\n2. **Inner Mastery Lounge**: This is our exclusive membership community that includes:\n   - Weekly group coaching sessions\n   - Access to guided meditations and exercises\n   - Community support and networking\n   - Monthly masterclasses on personal development topics\n   - Exclusive resources and tools for members\n\nAdditionally, we offer individual and group healing sessions focused on energy alignment, stress relief, emotional clarity, and mindfulness practices.\n\nIf you would like more details about a specific program, feel free to ask!	f	\N	["joveheal_sample.txt"]	\N
7	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:36:53.714989	can you tell me how do I increase my confidence?	While I can't provide specific advice, I can share general concepts that might be helpful in boosting confidence. \n\nParticipating in workshops, such as our **Confidence and Self-Leadership** workshop at JoveHeal, can provide valuable strategies and insights for building self-confidence. Additionally, consistent practice of setting and achieving small goals can help create a sense of accomplishment.\n\nJoining a supportive community, like the **Inner Mastery Lounge**, can offer encouragement and shared experiences that foster confidence. Engaging in regular self-reflection and mindfulness practices may also contribute to a stronger sense of self-worth.\n\nIf you’re interested in exploring these options as a way to build your confidence, feel free to ask about our programs or workshops!	f	\N	["joveheal_sample.txt"]	\N
8	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:37:37.446233	what program do you offer specifically for this purpose?	For building confidence, the **Balance Mastery+ Program** includes components that focus on developing confidence and self-leadership skills. This program guides you in mastering your mindset and overcoming limiting beliefs, which are crucial for increasing self-confidence.\n\nAdditionally, our **Confidence and Self-Leadership** workshop specifically targets skills and strategies to enhance your confidence. Participating in this workshop can provide practical tools and insights to help you on your confidence journey.\n\nIf you’d like more information on how to join these programs, just let me know!	f	\N	["joveheal_sample.txt"]	\N
9	468c3529-639b-4bf7-8242-95aad6438b11	2025-12-01 09:43:36.96863	do you offer relationship healing ... if yes share details?	Currently, JoveHeal focuses on wellness coaching and healing sessions that primarily include energy alignment, stress relief, emotional clarity, and mindfulness practices. While our services can support personal growth and emotional wellness, we do not specifically offer relationship healing programs.\n\nIf you're interested in personal development or healing, our individual and group healing sessions may provide benefits that can contribute to overall emotional well-being. Feel free to explore our programs or ask about any other topics that may interest you!	f	\N	["joveheal_sample.txt"]	\N
10	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:15.305637	What is relationship healing?	Relationship Healing at JoveHeal is a 3-hour deep healing session designed for individuals, particularly women, who seek to enhance intimacy and fulfillment in their relationships. It goes beyond surface-level solutions, focusing on root-level healing to dissolve old wounds and facilitate real transformation.\n\nKey components of Relationship Healing include:\n\n- **Guided Wound Release:** This helps to dissolve emotional pain associated with past experiences.\n- **The Mirror Principle:** This technique transforms relationship triggers into deeper connections.\n- **The 5 Core Wounds Map:** This tool enables participants to understand recurring patterns in their relationships and learn how to overcome them.\n\nThis healing space aims to help you turn conflicts into opportunities for deeper connection, rebuild trust, and reconnect with yourself, allowing you to show up with love and clarity in all your relationships. \n\nIf you're interested or have more questions, feel free to ask!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt"]	\N
11	302d0dfd-9320-4d5f-ad92-0f3a175d8c00	2025-12-01 09:58:53.933678	Tell me about Balance Mastery	Balance Mastery is a signature 3-month program at JoveHeal specifically designed for high-performing leaders who are seeking to restore balance in their lives. This program is aimed at those who may feel successful externally but are experiencing internal stress and misalignment.\n\nKey features of the Balance Mastery program include:\n\n- **Premium One-on-One Coaching:** You will have personalized sessions where you can uncover root causes, clear emotional and energetic blocks, and realign your inner landscape for a more harmonious outer life.\n- **Deep Root Healing:** This component helps you to identify and release limiting patterns.\n- **Blueprint Shift Work:** A focus on creating lasting transformation.\n- **Tools and Practices for Sustainable Change:** You will receive methodologies to support ongoing growth and balance.\n- **Personalized Support:** Throughout your journey, you will have access to dedicated support to help you achieve your goals.\n\nThis program is ideal for high-achieving professionals who want to deepen their relationships, lead with impact, and live with inner peace while overcoming the feelings of disconnection that often accompany success.\n\nIf you'd like more information or have specific questions about the program, feel free to ask!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N
12	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:05:37.137451	do you offer relationship healing ... if yes share details?	Yes, JoveHeal offers a Relationship Healing session designed for individuals seeking to enhance intimacy and fulfillment in their relationships. \n\n**Details of the Relationship Healing session:**\n- **Duration:** 3 hours\n- **Focus:** This deep healing session goes beyond quick fixes, guiding you into root-level healing where old wounds can dissolve and true transformation occurs.\n- **Key Components:**\n  - **Guided Wound Release:** Helps dissolve emotional pain.\n  - **The Mirror Principle:** Teaches how to transform relationship triggers into deeper connections.\n  - **The 5 Core Wounds Map:** Aids in understanding why patterns repeat in relationships and how to stop them.\n\nThis session is an opportunity to heal wounds that impact all your relationships, allowing you to show up with love and clarity.\n\nIf you have any more questions or need further information, feel free to ask!	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt", "website_balance_mastery.txt"]	\N
13	568b4563-8ccf-4738-bca0-b09d0e1a3fd3	2025-12-01 10:07:43.746671	thank you .. ok my issue is I feel sad disconnected, weighed down, whats the best program do you offer for this ?	For feelings of sadness, disconnection, and being weighed down, the **Inner Reset** course would be a great fit for you. \n\n**Details about the Inner Reset:**\n- **Focus:** This self-paced healing course is designed for high-performing individuals who feel soul-tired, disconnected, or burdened by emotions that rest and busyness can't seem to fix.\n- **Key Features:**\n  - Guides you through powerful practices such as inner child healing, emotional release, energetic clearing, and self-love activation.\n  - Allows you to move through the material at your own rhythm, providing lifetime access so you can revisit the process whenever needed.\n\nThis course invites you to pause and reconnect with who you truly are, beneath the pressures and survival patterns. \n\nIf this sounds like a good fit for you or if you have any other questions, feel free to ask!	f	\N	["website_elevate360.txt", "website_inner_mastery_lounge.txt", "website_services.txt"]	\N
14	eed23f1c-3d2e-4388-8078-a65d690c4f94	2025-12-01 10:24:47.233988	any membership you provide?	Yes, JoveHeal offers the **Inner Mastery Lounge**, which is our exclusive membership community. Membership includes the following benefits:\n\n- Weekly group coaching sessions\n- Access to guided meditations and exercises\n- Community support and networking\n- Monthly masterclasses on personal development topics\n- Exclusive resources and tools for members\n\nMembers also have access to all recorded sessions, allowing for a comprehensive experience in a supportive community of like-minded individuals. If you're interested in joining, please visit our website for more details!	f	\N	["joveheal_sample.txt", "website_elevate360.txt", "website_balance_mastery.txt"]	\N
15	860cab47-d476-44dc-af24-f3dda296dcc6	2025-12-01 11:03:37.905214	Who is the coach behind JoveHeal and what is their background?	The coach behind JoveHeal has over 20 years of experience in corporate leadership, specializing in Agile transformation and executive delivery. They went through a profound healing journey that reshaped their approach to coaching. Traditionally focused on strategy, this coach realized that emotional and energetic healing is essential for true transformation. \n\nTheir work now emphasizes guiding high-achieving executives and entrepreneurs to uncover and clear emotional patterns that may lead to burnout and decision fatigue, helping them lead from a place of wholeness. This unique blend of coaching integrates modern techniques with holistic wellness principles to foster profound personal transformation. \n\nIf you have any more questions about JoveHeal's services or programs, feel free to ask!	f	\N	["website_homepage.txt", "joveheal_sample.txt"]	\N
39	manychat_test123	2025-12-10 04:11:16.747538	hello	Hi Sam! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What’s on your mind today? I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "https://www.joveheal.com/contact", "website_elevate360.txt"]	\N
16	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:31:50.924017	I have a broken marriage .. and I am depressed, what course do you suggest?	I'm sorry to hear that you're going through such a difficult time. While I can't provide advice on healing your marriage or addressing feelings of depression, I can share information about JoveHeal's programs that may be helpful.\n\nYou might consider the **Relationship Healing** session, which is designed to help you work through core relationship wounds and enhance connection in your relationships. It's a deep healing session that focuses on transformative healing rather than quick fixes.\n\nIf you're looking for a more comprehensive approach, the **Inner Mastery Lounge** membership is also available. This program supports those who have outgrown surface-level solutions and are ready for deeper shifts in their relationships and personal well-being.\n\nFor personalized support specific to your situation, I encourage reaching out to a licensed therapist or counselor. If you have any more questions about the programs or how to get involved, feel free to ask!	f	\N	["website_balance_mastery.txt", "website_inner_mastery_lounge.txt", "website_elevate360.txt"]	\N
17	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:32:15.789454	ok how do I enroll to this course ..	To enroll in the Relationship Healing course or any other program at JoveHeal, you can visit our website at www.joveheal.com. Once there, please use the contact form for inquiries about specific courses, membership options, and any enrollment processes.\n\nIf you have further questions about the courses or need assistance, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "joveheal_sample.txt", "website_services.txt"]	\N
18	7606ae71-395d-45d0-bafb-d5d39fc79661	2025-12-01 11:33:30.420205	I some times feel to take my own life can you help?	I'm really sorry to hear that you're feeling this way. It's very important to speak with someone who can help you, like a licensed therapist or mental health professional. If you're in immediate distress, please reach out to a crisis hotline or local support services in your area. You don't have to go through this alone—there are people who want to help you.\n\nPlease take care of yourself, and I encourage you to seek the support you deserve.	f	\N	["website_elevate360.txt", "website_balance_mastery.txt", "website_beyond_the_hustle.txt"]	\N
19	user_sammy_test	2025-12-04 05:57:21.326436	What programs do you offer?	At JoveHeal, we offer several transformative programs designed to support personal growth and healing. Our key offerings include:\n\n1. **1:1 Private Coaching** - A personalized program for high achievers seeking deep transformational work.\n   \n2. **Transformational Course Library** - This includes courses like [Inner Reset](https://joveheal.com/inner-reset/), [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/), [Career Healing](https://joveheal.com/career-healing/), and [Relationship Healing](https://joveheal.com/relationship-healing/), covering various aspects of personal and professional growth.\n\nIf you're interested in a specific program or want to know more, feel free to ask!	f	\N	["website_inner_mastery_lounge.txt", "website_about.txt", "website_homepage.txt"]	\N
20	user_sammy_new_session	2025-12-04 05:57:50.521872	Tell me more about the first one you mentioned	The **1:1 Private Coaching** program at JoveHeal is a deeply personalized experience designed for high achievers and leaders who might feel successful in their careers but are struggling with internal challenges. This coaching aims to facilitate profound transformation by addressing emotional blocks and restoring balance in life.\n\nCoaching sessions guide you through uncovering the roots of stress, enhancing self-awareness, and implementing strategies that culminate in lasting change. Each session is tailored to your unique journey, allowing for a safe space to heal and grow.\n\nWould you like more information about how to get started with this program or connect with our team?\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Career Healing](https://joveheal.com/career-healing/) | [Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) | [Inner Reset](https://joveheal.com/inner-reset/)	f	\N	["website_services.txt", "website_inner_mastery_lounge.txt"]	\N
21	guest_1764828759834_sw15y6o92	2025-12-04 06:13:59.133056	I am suffering from a self low esteem what should I do?	I'm really sorry to hear that you're feeling this way. It's completely understandable to struggle with self-esteem sometimes. While I can't provide specific advice or solutions, I encourage you to consider exploring JoveHeal's programs, like "[Shed & Shine](https://joveheal.com/shed-and-shine/)," which focuses on releasing emotional weight and enhancing self-worth. If you're interested, I can share more details or help connect you with JoveHeal's team.	f	\N	["website_elevate360.txt", "website_shed_and_shine.txt", "website_testimonials.txt"]	\N
22	guest_1764828759834_sw15y6o92	2025-12-04 06:14:17.029972	please provide me the details for this ..	"[Shed & Shine](https://joveheal.com/shed-and-shine/)" is a self-paced digital course designed to help you let go of emotional weight and unlock a lighter you. It offers lifetime access to meditations and digital recordings, which can support your journey toward greater self-worth and freedom from emotional patterns.\n\nThis course is particularly beneficial if you feel stuck in cycles of emotional eating, self-sabotage, or guilt around self-care. It's about addressing not just physical challenges but also the emotional ones that can hold you back.\n\nIf you'd like to learn more about enrolling in the course or have other questions about JoveHeal's offerings, I can help connect you with their team!	f	\N	["website_inner_mastery_lounge.txt", "website_shed_and_shine.txt", "website_homepage.txt"]	\N
23	test_shed_shine	2025-12-04 06:23:00.175464	Tell me about Shed and Shine program	The [Shed & Shine](https://joveheal.com/shed-and-shine/) program is a 5-week self-paced digital course designed to help you understand and release the emotional weight you're carrying, both physically and mentally. Throughout the course, you'll explore the root emotional causes behind your weight, reprogram your mindset for a healthier relationship with yourself, and build sustainable habits to support your well-being. You'll gain lifetime access to meditations and digital recordings to revisit whenever you need. It's all about addressing what's in your heart, mind, and soul rather than just the scale. Would you like more details on how to get started or something else?	f	\N	["website_inner_mastery_lounge.txt", "website_shed_and_shine.txt", "website_services.txt"]	\N
24	user_sammy@test.com	2025-12-04 07:34:51.550947	hi	Hi Sammy! It’s great to see you back here! How can I support you today? If you have more questions about our programs or anything else, I’m all ears!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/) | [Elevate 360](https://joveheal.com/elevate-360/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
25	user_newuser@example.com	2025-12-04 07:35:06.292902	hi	Hi Priya! I’m RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you have questions about our offerings or are just curious, I'm here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
26	guest_1764833832077_yp756jiqr	2025-12-04 07:37:24.393672	what programs does JoveHeal offer?	JoveHeal offers several programs focused on wellness coaching and personal transformation. One of the key offerings is the [Balance Mastery](https://joveheal.com/balance-mastery/)+ program, designed to help participants develop clarity about their goals, build sustainable routines, master their mindset, and achieve work-life balance. There’s also the [Inner Mastery Lounge](https://joveheal.com/inner-mastery-lounge/), which is an ongoing membership option. If you'd like more details or specific information about any program, feel free to ask!	f	\N	["joveheal_sample.txt", "website_contact.txt", "website_homepage.txt"]	\N
27	guest_1764833832077_yp756jiqr	2025-12-04 07:37:42.157292	tell me more about Balance Mastery	[Balance Mastery](https://joveheal.com/balance-mastery/) is a 3-month coaching program tailored for high-performing leaders who may feel successful externally but struggle internally. This program combines one-on-one sessions focused on uncovering the root causes of stress, clearing emotional blocks, and realigning one's internal landscape.\n\nParticipants can expect to gain sustainable calm, clarity in their decisions, and a revitalized energy to support both their leadership and personal lives. The program includes deep root healing, a blueprint shift for lasting transformation, and personalized support throughout the journey. It’s a great option for those looking to reclaim joy and alignment within themselves. \n\nIf you’d like more specifics or have any questions, just let me know!	f	\N	["website_services.txt", "joveheal_sample.txt", "website_balance_mastery.txt"]	\N
28	user_test@summary.com	2025-12-04 07:53:23.834091	I feel disconnected from society and stressed about my career	I'm really sorry to hear that you're feeling this way, Test. It's tough to feel disconnected and stressed, especially regarding something as important as your career. JoveHeal offers a program called "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" that helps uncover emotional patterns that might be impacting your well-being and career satisfaction. Would you like to learn more about that or connect with someone from our team for support?	f	\N	["website_beyond_the_hustle.txt", "website_career_healing.txt", "website_elevate360.txt"]	\N
29	user_test@summary.com	2025-12-04 07:54:01.42505	yes tell me more about Beyond the Hustle	Absolutely, Test! "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a soul-shifting masterclass designed for those who appear successful on the outside but feel drained and disconnected on the inside. It focuses on uncovering the emotional roots behind feelings of exhaustion and stuckness.\n\nIn the program, you'll learn about the invisible patterns shaping your career and relationships, and why traditional mindset work often falls short. It includes a guided healing shift to help you release one limiting belief in real time, and provides practical insights on rebuilding your life from your inner truth.\n\nParticipants often leave feeling lighter, clearer, and more seen, equipped with tools that truly make a difference. If you're interested, I can help connect you further with the JoveHeal team!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N
30	user_test@summary.com_new_session	2025-12-04 07:54:31.753761	hi	Hi again, Test! It’s great to hear from you. How can I assist you today? Whether you have more questions about our programs or something else on your mind, I’m here to help!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
31	user_test@summary.com_session2	2025-12-04 07:55:29.336616	hi	Hi Test! I’m here and ready to help. What would you like to chat about today?	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
32	user_test@summary.com_session3	2025-12-04 07:56:21.594792	hi	Hi Test! It looks like you might be trying to connect again. Is there something specific you'd like to discuss or ask about? I'm all ears!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
33	user_test@summary.com_session4	2025-12-04 07:57:22.043668	hi	Hi Test! It's wonderful to see you back. If there's anything on your mind or something you'd like to explore today, just let me know. I'm here to help!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
34	user_test@summary.com_session5	2025-12-04 07:58:10.668354	hi	Hi Test! It's lovely to have you here again. If there's anything you'd like to talk about or ask, feel free to share. I'm here for you!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
35	user_test@summary.com_session6	2025-12-04 07:59:17.093107	hi	Hi Test! Great to see you back! I remember you mentioned feeling disconnected from society and stressed about your career. Would you like to continue exploring these feelings or discuss the "[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" program we talked about? I'm here to help!	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
36	test_456	2025-12-04 11:26:52.607878	hello there	Hello! I’m RACEN, your guide for exploring JoveHeal's healing and coaching programs. What’s on your mind today? I'm here to help with any questions you have!\n\n---\n\n*Here are some programs that align with what we discussed:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_testimonials.txt", "https://www.joveheal.com/balance-mastery"]	\N
37	test_789	2025-12-04 11:27:05.320738	tell me about beyond the hustle program	"[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/)" is a transformative masterclass designed for individuals who seem successful on the outside but feel drained and disconnected internally. This program helps participants uncover the hidden emotional patterns that impact their careers, relationships, and overall well-being. You'll engage in guided healing work to address limiting beliefs, gain clarity, and learn how to rebuild your life based on your inner truth rather than external pressures. \n\nIt's a deep, soul-shifting experience that goes beyond traditional mindset work, providing tools to feel lighter and more aligned with your true self. Would you like more details or to connect with the JoveHeal team?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N
38	manychat_insta_12345	2025-12-10 03:43:51.185699	What is Beyond the Hustle?	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a transformative masterclass for those who appear successful on the outside but feel drained and disconnected on the inside. It helps break the cycle of overgiving, exhaustion, and silent suffering, allowing participants to uncover the emotional roots behind their struggles and create meaningful change. You'll gain awareness of hidden patterns, experience guided healing shifts, and learn how to rebuild your life from inner truth rather than pressure. If you're feeling stuck or unfulfilled, this might be the right fit for you! Would you like to know more about the program?	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N
40	widget_1765353094047_v5ueg562z	2025-12-10 07:52:05.989813	Tell me about JoveHeal	JoveHeal is a wellness coaching business focused on helping individuals achieve balance, clarity, and personal transformation through mindset coaching and healing practices. With a mission that emphasizes everyone’s right to a purposeful and peaceful life, JoveHeal combines modern coaching techniques with holistic wellness principles. They offer programs such as the [Balance Mastery](https://joveheal.com/balance-mastery/)+ program, designed to help high-performing leaders develop clarity about their life goals, create sustainable daily routines, and build self-leadership skills. If you’re curious about specific programs or services, feel free to ask!	f	\N	["website_homepage.txt", "joveheal_sample.txt"]	\N
41	widget_1765353332794_h56duugt7	2025-12-10 07:56:06.778024	What is Beyond the Hustle program? (no changes needed)	[Beyond the Hustle](https://joveheal.com/beyond-the-hustle/) is a transformative masterclass designed for those who appear successful on the outside but feel drained and disconnected on the inside. It focuses on uncovering the emotional roots behind exhaustion and patterns of overgiving, providing a guided healing experience to release limiting beliefs. Participants learn about the hidden patterns affecting their lives, gaining practical insights to rebuild from their inner truth. If you're interested in exploring this program further, let me know!	f	\N	["website_services.txt", "website_beyond_the_hustle.txt", "website_inner_mastery_lounge.txt"]	\N
42	guest_1765360643640_nl7idovap	2025-12-10 09:57:52.442908	hi	Hi there! I'm RACEN, your guide for exploring JoveHeal's healing and coaching programs. What brings you here today? Whether you're curious about our offerings or looking for support, I'm happy to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Balance Mastery](https://joveheal.com/balance-mastery/) | [Services](https://joveheal.com/services/) | [Healing Sessions](https://joveheal.com/healing-sessions/)	f	\N	["website_balance_mastery.txt", "website_elevate360.txt", "website_about.txt"]	\N
43	guest_1765436537649_mp6r1efp3	2025-12-11 07:03:17.866718	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, we're happy to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
44	guest_1765436789488_tqadnrc3c	2025-12-11 07:10:56.410279	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, we're happy to assist you!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
45	guest_1765436789488_tqadnrc3c	2025-12-11 07:14:28.050056	which product will you suggest for sex enhancements	For sexual enhancement, we recommend the following Ayurvedic products that have been designed to support performance and stamina:\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**:\n   - **Price**: Rs. 999 (originally Rs. 1,799 - 44% off)\n   - **Description**: A natural massage oil formulated to promote blood circulation and support natural enlargement.\n   - **Key Ingredients**: Ashwagandha, Safed Musli, Shatavari.\n   - **How to Use**: Apply and massage gently for 10-15 minutes daily.\n   - [Check it out here](https://naturemania.in/products/lift-up-oil).\n\n2. **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)**:\n   - **Price**: Rs. 1,312 (originally Rs. 1,399 - 6% off)\n   - **Description**: These capsules are designed to enhance performance and support overall sexual health.\n   - [More info here](https://naturemania.in/products/perm-up-capsule).\n\n3. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**:\n   - **Price**: Rs. 1,031 (originally Rs. 1,099 - 6% off)\n   - **Description**: Formulated to help improve testosterone levels, aiding in sexual health and stamina.\n   - [Explore here](https://naturemania.in/products/tes-up-capsule).\n\n4. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**:\n   - **Price**: Rs. 1,218 (originally Rs. 1,299 - 6% off)\n   - **Description**: These capsules are aimed at enhancing vitality and stamina in men.\n   - [Learn more here](https://naturemania.in/products/vit-up-capsule).\n\nExtra 5% Off on Prepaid Orders! We also offer Free Shipping across India!\n\nIf you need further assistance or have specific concerns, feel free to reach out to us!	f	\N	["blog_articles.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N
46	widget_1765437289627_ttdtyw4pj	2025-12-11 07:15:30.194519	Hello, what programs do you offer? (no changes needed)	Hi there! We have a variety of transformative programs at JoveHeal. Our main offerings include:\n\n1. **[Balance Mastery](https://joveheal.com/balance-mastery/)**: A 3-month 1:1 coaching program designed for high-achieving professionals seeking to uncover emotional blocks and restore balance in their lives.\n\n2. **[Elevate 360](https://joveheal.com/elevate-360/)**: A 5-month program focusing on healing and rebuilding your emotional foundation to enhance your life across all dimensions.\n\nWe also provide access to high-frequency transformation tools, exclusive member discounts, and a supportive private community. If you’d like more details on any specific program, just let me know!	f	\N	["website_homepage.txt", "website_inner_mastery_lounge.txt", "website_contact.txt"]	\N
47	widget_1765437473959_j1h9txyv1	2025-12-11 07:18:26.275902	What is Balance Mastery?	[Balance Mastery](https://joveheal.com/balance-mastery/) is our 3-month 1:1 coaching program tailored for high-performing leaders who feel successful on the outside but are struggling internally. The program focuses on uncovering stress roots, releasing emotional blocks, and restoring balance in your life. You'll receive personalized support, deep root healing, and tools for lasting transformation so you can lead with impact and live with inner peace. If you'd like more details or have specific questions, feel free to ask!	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N
48	guest_1765437466934_bpzixcb5n	2025-12-11 07:19:26.102906	hi	Hi there! We're glad to see you here at Nature Mania. How can we assist you today? Whether you have questions about our Ayurvedic products or need help choosing the right solution, feel free to ask!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
49	widget_1765437473959_j1h9txyv1	2025-12-11 07:19:33.103406	How much does it cost? (no changes needed)	You can see the pricing for [Balance Mastery](https://joveheal.com/balance-mastery/) and enroll at [this link](https://www.joveheal.com/offers/osL3L3qG/checkout). If you'd prefer a personalized one-to-one session with Shaveta, you can also book a complimentary Discovery Call instead. Would you like me to help you with that?	f	\N	["website_services.txt", "website_balance_mastery.txt", "joveheal_sample.txt"]	\N
50	guest_1765437466934_bpzixcb5n	2025-12-11 07:19:53.306864	what product do you suggest for sex enhancements?	For sex enhancement, we recommend the following Ayurvedic products that can support performance and overall wellbeing:\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**  \n   - **Price:** Rs. 999 (was Rs. 1,799 - 44% off!)\n   - A natural men's massage oil designed to promote blood circulation and support natural enhancement.  \n   - [Check it out here](https://naturemania.in/products/lift-up-oil)\n\n2. **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)**  \n   - **Price:** Rs. 1,312 (was Rs. 1,399 - 6% off!)\n   - These capsules help improve stamina and performance.  \n   - [Explore here](https://naturemania.in/products/perm-up-capsule)\n\n3. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**  \n   - **Price:** Rs. 1,031 (was Rs. 1,099 - 6% off!)\n   - Effective for enhancing testosterone levels and sexual performance.  \n   - [Learn more here](https://naturemania.in/products/tes-up-capsule)\n\n4. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**  \n   - **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off!)\n   - Useful for boosting overall vitality and stamina.  \n   - [View details here](https://naturemania.in/products/vit-up-capsule)\n\nWe recommend using these products in combination for the best results. Remember, it's important to consult a healthcare professional for any specific health concerns.\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N
51	guest_1765437466934_bpzixcb5n	2025-12-11 07:20:28.804156	do you offer any discounts	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	\N	\N	\N
52	guest_1765437466934_bpzixcb5n	2025-12-11 07:21:04.794355	what is prepaid orders?	Prepaid orders refer to purchases where the payment is completed at the time of placing the order, rather than at the time of delivery. When you choose to pay in advance, you can enjoy **Extra 5% Off on Prepaid Orders** at Nature Mania.\n\nHere’s how it works:\n- You place your order online for any of our products.\n- At checkout, you select a prepaid payment option (like credit/debit card, net banking, or UPI).\n- Once the payment is processed, your order is confirmed, and you may receive the discount.\n\nThis payment method also assists in quicker processing and shipping of your orders. If you have any more questions or need help with the ordering process, feel free to ask!	f	\N	["products_lift_up.txt", "products_sexual_health.txt", "naturemania_company.txt"]	\N
53	guest_1765437466934_bpzixcb5n	2025-12-11 07:21:57.328367	koi herbal oil hai aapke paas?	Haan, humare paas ek herbal oil hai jo aapko zaroor pasand aayega:\n\n### **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**  \n- **Price:** Rs. 999 (pehle Rs. 1,799 tha - 44% off!)\n- **Size:** 30ml\n\n**Fayde:**\n- Blood circulation badhata hai\n- Natural enlargement mein madad karta hai\n- Stamina aur performance improve karta hai\n- 100% Ayurvedic aur AYUSH Certified hai\n\n**Kaise use karein:** Rozana 10-15 minute tak halka sa massage karein.\n\n**Yahan dekhein:** [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\nPrepaid orders par Extra 5% Off! Free Shipping across India! Agar aapko aur koi madad chahiye ho toh zaroor batayen!	f	\N	["products_lift_up.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
54	guest_1765438454208_nejh7kjn5	2025-12-11 07:34:23.70132	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
55	guest_1765438484407_96s7qm87l	2025-12-11 07:34:51.116764	hi	Hi there! We're NIRA, your friendly assistant at Nature Mania. What brings you here today? If you have any questions about our Ayurvedic products or need help with anything specific, just let us know!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
56	guest_1765438484407_96s7qm87l	2025-12-11 07:36:31.103656	erection ke liye koi medicine hai aapke paas?	Haan, hamaare paas kuch Ayurvedic products hain jo aapke liye madadgar ho sakte hain. Aapko [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) aur [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) dekhne chahiye.\n\n1. **Perm-Up Capsules**: Ye capsules premature discharge me madad karte hain aur intimacy ke doran timing aur control improve karte hain.\n   - **Price**: Rs. 1,312 (pehle Rs. 1,399 - 6% off)\n   - [Perm-Up Capsules dekhein](https://naturemania.in/products/perm-up-capsule)\n\n2. **Tes-Up Capsules**: Ye stamina aur endurance boost karne me madad karte hain, jo intimate performance ko improve kar sakta hai.\n   - **Price**: Rs. 1,031 (pehle Rs. 1,099 - 6% off)\n   - [Tes-Up Capsules dekhein](https://naturemania.in/products/tes-up-capsule)\n\nInhe daily use karna chahiye for best results. Agar aapko aur jaanana hai ya kisi aur product ke liye madad chahiye, to humein zaroor batayein! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_sexual_health.txt", "blog_articles.txt"]	\N
57	guest_1765438484407_96s7qm87l	2025-12-11 07:37:55.986649	mein aapna sex stamina kaise badha sakta hun?	Aap apne sex stamina ko badhane ke liye kuch natural tarike aur Ayurvedic supplements istemal kar sakte hain. Yahan kuch tips aur remedies hain jo madadgar ho sakti hain:\n\n1. **Ayurvedic Herbs**: Ashwagandha, Shilajit, aur Safed Musli jaise herbs ka istemal karein, jo stamina aur energy ko badhane me madad karte hain.\n\n2. **Regular Exercise**: Cardio aur strength training se stamina improve hota hai. Kegel exercises bhi pelvic floor muscles ko majboot karne me madadgar hain.\n\n3. **Healthy Diet**: Protein-rich foods, fruits, aur vegetables khayen. Yeh aapki overall health aur stamina ko sudharega.\n\n4. **Adequate Sleep**: Har raat 7-8 ghante ka achha neend lena zaroori hai, kyunki yeh hormone balance aur energy levels ke liye important hai.\n\n5. **Stress Reduction**: Yoga aur meditation se stress kam karne se aapki stamina aur performance improve hoti hai.\n\n6. **Natural Supplements**: Aap hamaare Ayurvedic products jaise **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)** aur **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** ko bhi consider kar sakte hain:\n   - **Tes-Up Capsules**: Rs. 1,031 - [Tes-Up Capsules dekhein](https://naturemania.in/products/tes-up-capsule)\n   - **Vit-Up Capsules**: Rs. 1,218 - [Vit-Up Capsules dekhein](https://naturemania.in/products/vit-up-capsule)\n\nInhe regular use karne se aapke stamina mein sudhar dekha ja sakta hai. Yadi aapko aur jaankari chahiye ya kisi specific product ke bare mein poochna hai, to humein zaroor batayein!\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
58	stress_test_0	2025-12-11 10:14:39.198919	What products does Naturemania offer? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N
59	stress_test_1	2025-12-11 10:14:42.686278	How much does Lift-Up Oil cost? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) costs Rs. 999 (originally Rs. 1,799 - 44% off!). \n\nYou can check it out here: https://naturemania.in/products/lift-up-oil\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
60	stress_test_4	2025-12-11 10:14:43.97761	Which products are for women? (no changes needed)	We have a great selection of products specifically designed for women's wellness:\n\n1. **[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)**\n   - Purpose: Breast enhancement, shaping, and uplifting.\n   - Price: Rs. 843 (was Rs. 899 - 6% off)\n   - URL: [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\nYou can explore our entire range of products here: [All Products](https://naturemania.in/collections/all).\n\nIf you need more information, feel free to contact us!	f	\N	["blog_articles.txt", "products_women_wellness.txt", "products_lift_up.txt"]	\N
61	stress_test_3	2025-12-11 10:14:44.089933	What are the benefits of Perm-Up Capsules? (no changes needed)	[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) are formulated to help men with premature discharge issues. The Ayurvedic formula works naturally to improve timing and control during intimacy.\n\n**Key Benefits:**\n- Helps control premature discharge\n- Improves timing and duration\n- Boosts confidence during intimacy\n- Reduces performance anxiety\n- Enhances stamina and endurance\n- 100% Ayurvedic Ingredients\n- AYUSH Certified\n- No side effects\n\nFor more information, check out the product here: [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule).\n\n**Price:** Rs. 1,312 (Discounted from Rs. 1,399 - 6% off!)  \nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N
62	stress_test_2	2025-12-11 10:14:44.889054	Tell me about Shilajit Gold Resin	[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin) is a powerful natural supplement known for its energy-boosting and vitality-enhancing properties. Sourced from the Himalayas, this premium resin is formulated to support overall well-being and enhance physical performance.\n\n**Price:** Rs. 1,171 (original price Rs. 1,249 - 6% off!)\n\n**Size:** 20gm\n\nKey benefits:\n- Boosts energy and stamina\n- Enhances physical performance\n- Supports natural testosterone levels\n- Improves mental clarity\n- Rich in fulvic acid and minerals\n- 100% Pure and Natural\n\n**How to use:** Take one capsule twice daily with lukewarm water or milk after meals. It is recommended to use it for at least 2-3 months for optimal results.\n\nFeel free to check it out here: [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N
63	stress_test_5	2025-12-11 10:14:50.026659	Do you have any discounts?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N
64	stress_test_7	2025-12-11 10:14:52.633131	What is the price of Tes-Up? (no changes needed)	The price of [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) is Rs. 1,031.00, discounted from Rs. 1,099.00 (6% off). \n\nYou can check it out here: https://naturemania.in/products/tes-up-capsule\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_general_wellness.txt", "blog_articles.txt"]	\N
65	stress_test_6	2025-12-11 10:14:52.927954	How to use Lift-Up Capsules?	To use [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules), follow these instructions:\n\n- **Dosage:** Take 1-2 capsules twice daily.\n- **Best taken with:** Lukewarm water or milk.\n- **Timing:** Consume them 30 minutes after meals for optimal absorption.\n\nFor best results, we recommend using the capsules for at least 2-3 months.\n\nYou can check out Lift-Up Capsules here: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)\n\n**Price:** Rs. 1,499 (was Rs. 1,699 - 12% off!)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
66	stress_test_8	2025-12-11 10:14:54.5329	Tell me about Cup-Up Capsules	[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules) are designed specifically for breast enhancement, shaping, and uplifting. They provide a safe and natural way to increase breast size without the need for costly surgeries or potentially harmful medications.\n\n**Price:** Rs. 843 (was Rs. 899 - 6% off!)\n\n**Key Benefits:**\n- Increases breast size naturally\n- Helps in breast toning and firming\n- Plumps, firms, and uplifts breasts\n- Improves cup size and smoothens skin\n- Tightens and shapes breasts, reducing sagging\n- Balances uneven breasts and improves hormonal balance\n- 100% Ayurvedic ingredients with no known side effects\n- AYUSH Certified\n\n**How to Use:** Take one capsule in the morning and one in the evening with lukewarm water, 20 minutes after meals. For best results, it is recommended to use continuously for 60-90 days.\n\n**Key Ingredients:** \n- Ashwagandha\n- Gambhari\n- Motha\n- Shatavari\n- Methi\n\nYou can find more details and purchase the Cup-Up Capsules here: [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\nRemember, we have **Extra 5% Off on Prepaid Orders** and **Free Shipping across India**!	f	\N	["products_women_wellness.txt", "products_lift_up.txt", "products_sexual_health.txt"]	\N
67	stress_test_9	2025-12-11 10:15:02.491542	How can I place an order?	Placing an order is simple! Here’s how you can do it:\n\n1. **Visit our Website**: Go to [Nature Mania's website](https://naturemania.in/).\n2. **Browse Products**: Browse through our range of Ayurvedic products on the [All Products page](https://naturemania.in/collections/all).\n3. **Select Products**: Click on the product you are interested in to view the details and add it to your cart.\n4. **Proceed to Checkout**: Once you have selected all the products you want, go to your cart and click on 'Checkout'.\n5. **Fill in Your Details**: Enter your shipping information and choose your payment method. We offer Cash on Delivery (COD) and prepaid options.\n6. **Confirm Your Order**: Review your order and confirm it!\n\nIf you have any questions or need further help, feel free to [contact us](https://naturemania.in/pages/contact) or call us at 75092-76000. Happy shopping! \n\n**Extra 5% Off on Prepaid Orders!** Enjoy **Free Shipping** across India!	f	\N	["naturemania_company.txt", "products_lift_up.txt"]	\N
68	stress_test_11	2025-12-11 10:15:07.158272	Do you offer free shipping? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N
69	stress_test_12	2025-12-11 10:15:10.474984	What are the ingredients in Lift-Up Oil? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is made with a combination of natural Ayurvedic ingredients that include:\n\n- Ashwagandha\n- Safed Musli\n- Shatavari\n- Other Ayurvedic herbs\n\nThese ingredients are formulated to promote blood circulation and support natural enhancement. \n\nFor more details, you can check it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil). \n\nIf you have any more questions, feel free to ask!	f	\N	["products_lift_up.txt", "products_general_wellness.txt"]	\N
70	stress_test_13	2025-12-11 10:15:10.624462	Are products safe for diabetics? (no changes needed)	Our products are natural Ayurvedic supplements designed to support overall wellness. However, they are not formulated specifically for diabetics or as treatment for diabetes. Therefore, we recommend that anyone with health conditions, including diabetes, consult with a qualified healthcare professional before using our products. \n\nIf you would like to know more about specific products or need assistance, feel free to reach out to us! You can explore our offerings at [Nature Mania](https://naturemania.in/).	f	\N	["products_general_wellness.txt", "naturemania_company.txt", "blog_articles.txt"]	\N
71	stress_test_10	2025-12-11 10:15:11.54673	What makes Naturemania products different? (no changes needed)	Nature Mania products stand out due to several key factors:\n\n1. **100% Ayurvedic Ingredients:** We believe in the power of Ayurveda, using only pure Ayurvedic ingredients in our formulations.\n\n2. **Experienced Team:** Our products are formulated by experienced Ayurvedic doctors who ensure a blend of traditional wisdom and modern science.\n\n3. **AYUSH Certified:** All our products are certified by AYUSH, ensuring their quality and efficacy.\n\n4. **No Side Effects:** We focus on natural solutions with no harmful side effects, promoting overall well-being.\n\n5. **User-Friendly:** Our products are easy to use, making it convenient for our customers to incorporate wellness into their daily lives.\n\n6. **Wide Range of Products:** We offer a diverse selection of natural wellness supplements to address various health needs.\n\nThese attributes combined make our products unique and effective for our customers' health and wellness journeys. For more information about our products, feel free to check them out here: [All Products](https://naturemania.in/collections/all).	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
72	stress_test_14	2025-12-11 10:15:19.488958	What is Smart Shaping Powder used for? (no changes needed)	[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder) is a high-quality blend designed for effective fat metabolism, increased energy, and improved endurance. Specifically, it helps to use fat as an energy source for active lifestyles. \n\nHere are some key benefits of Smart Shaping Powder:\n- Supports advanced fat metabolism\n- Boosts energy levels and endurance\n- Accelerates post-workout recovery\n- Enhances brain health and mental clarity\n- Pure, safe, and effective formula with no artificial additives or fillers\n\n**How to use:** Mix one sachet with 250ml chilled water, shake for 20-30 seconds, and drink. It's best consumed 30 minutes before a workout.\n\n**Price:** Rs. 2,249 (was Rs. 3,699 - 39% off!)\n\nYou can check out Smart Shaping Powder here: [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_women_wellness.txt"]	\N
73	stress_test_15	2025-12-11 10:15:25.732878	How long does delivery take?	Delivery typically takes 2-6 working days across India. Orders are dispatched within 48 hours. If you need your order faster, we also offer express shipping at a nominal cost. Plus, we provide free shipping on all orders!\n\nIf you have any more questions or need assistance, feel free to contact us!	f	\N	["products_general_wellness.txt", "naturemania_company.txt", "products_women_wellness.txt"]	\N
74	stress_test_16	2025-12-11 10:15:27.45871	Can I pay cash on delivery? (no changes needed)	Yes, you can pay cash on delivery (COD) for your orders with us. We offer this option across India for your convenience. If you have any more questions or need assistance with placing an order, feel free to contact us!\n\nFor more information, you can visit our website: https://naturemania.in/	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N
75	stress_test_19	2025-12-11 10:15:28.385952	How to contact customer support? (no changes needed)	To contact our customer support, you can reach us through the following:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n**Contact Page:** https://naturemania.in/pages/contact  \n\nWe're here to assist you!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_women_wellness.txt"]	\N
76	stress_test_18	2025-12-11 10:15:29.651823	Tell me about Vit-Up Capsules	[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule) are a comprehensive multivitamin supplement designed to provide essential vitamins and minerals for overall health support.\n\n**Price:** Rs. 1,218 (originally Rs. 1,299 - 6% off!)\n**Size:** 60 Capsules\n\n### Key Benefits:\n- Boosts immune system\n- Provides essential nutrients\n- Increases stamina and endurance\n- Improves blood circulation and hormone balance\n- Enhances energy levels\n- Strengthens the immune system\n\n### Key Ingredients:\n- Aawla/Amla, Ashwagandha, Loh Bhasam, Vidarikand, Shilajit, and others rich in antioxidants and various vitamins.\n\n### How to Use:\nTake one Vit-Up capsule twice a day with water, after meals. Consistent use is recommended for the best results.\n\nYou can check out Vit-Up Capsules here: [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)\n\n**Extra 5% Off on Prepaid Orders! Free Shipping across India!**	f	\N	["products_general_wellness.txt", "products_sexual_health.txt", "blog_articles.txt"]	\N
88	stress_test_11	2025-12-11 10:29:55.503423	Do you offer free shipping?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N
90	stress_test_13	2025-12-11 10:29:59.463879	Are products safe for diabetics?	While we provide Ayurvedic wellness products, our team cannot give specific medical advice regarding safety for diabetics or any other health conditions. We recommend consulting with a qualified healthcare professional to determine the suitability of our products for your individual health needs.\n\nIf you're interested in exploring our Ayurvedic offerings, feel free to visit our website: [Nature Mania All Products](https://naturemania.in/collections/all). \n\nLet us know if you need any further assistance!	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N
77	stress_test_17	2025-12-11 10:15:32.060923	What products help with stamina? (no changes needed)	We offer several products that can help boost stamina and enhance performance. Here are some of our Ayurvedic supplements designed for stamina improvement:\n\n1. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**  \n   **Price:** Rs. 1,031 (was Rs. 1,099 - 6% off)  \n   [Learn more here](https://naturemania.in/products/tes-up-capsule)\n\n2. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**  \n   **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off)  \n   [Learn more here](https://naturemania.in/products/vit-up-capsule)\n\n3. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**  \n   **Price:** Rs. 999 (was Rs. 1,799 - 44% off)  \n   [Learn more here](https://naturemania.in/products/lift-up-oil)\n\n4. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)**  \n   **Price:** Rs. 1,171 (was Rs. 1,249 - 6% off)  \n   [Learn more here](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nThese products are made with natural ingredients that can support energy levels and enhance stamina. Remember, for specific health concerns, it's always best to consult a healthcare professional.\n\nAlso, don’t forget that you can enjoy **Extra 5% Off on Prepaid Orders** and **Free Shipping** across India! If you have any further questions or need assistance, feel free to reach out to us!	f	\N	["blog_articles.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
78	stress_test_0	2025-12-11 10:29:35.538878	What products does Naturemania offer? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N
79	stress_test_1	2025-12-11 10:29:38.844091	How much does Lift-Up Oil cost? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) costs **Rs. 999** (originally Rs. 1,799 - 44% off!). \n\nYou can check it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
80	stress_test_2	2025-12-11 10:29:40.159486	Tell me about Shilajit Gold Resin	Nature Mania [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin) is a powerful natural supplement sourced from the Himalayas, known for its energy-boosting and vitality-enhancing properties.\n\n**Price:** Rs. 1,171 (was Rs. 1,249 - 6% off!)\n**Size:** 20gm\n\n**Key Benefits:**\n- Boosts energy and stamina\n- Enhances physical performance\n- Supports natural testosterone levels\n- Improves mental clarity\n- Rich in fulvic acid and minerals\n- 100% Pure and Natural\n\n**How to Use:** Take one capsule twice daily with lukewarm water or milk after meals for optimal results.\n\nYou can check it out here: [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N
81	stress_test_3	2025-12-11 10:29:40.257615	What are the benefits of Perm-Up Capsules? (no changes needed)	[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) are formulated to help men with premature discharge issues. The Ayurvedic formula works naturally to improve timing and control during intimacy.\n\n**Key Benefits:**\n- Helps control premature discharge\n- Improves timing and duration\n- Boosts confidence during intimacy\n- Reduces performance anxiety\n- Enhances stamina and endurance\n- 100% Ayurvedic Ingredients\n- AYUSH Certified\n- No side effects\n\nFor more details, you can check out the product here: [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)\n\n**Price:** Rs. 1,312 (originally Rs. 1,399 - 6% off)! \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_lift_up.txt", "products_women_wellness.txt"]	\N
82	stress_test_4	2025-12-11 10:29:40.323469	Which products are for women?	We have some great products for women's wellness. Here are our offerings:\n\n1. **[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)**  \n   - **Price:** Rs. 843 (Discounted from Rs. 899 - 6% off)  \n   - **Description:** These capsules are designed for breast enhancement, shaping, and uplifting. They are made with 100% Ayurvedic ingredients with no side effects.  \n   - **Key Benefits:** Increases breast size naturally, helps in toning and firming, balances uneven breasts, and improves hormonal imbalance.  \n   - **Learn more here:** [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\nIf you need more information or have any specific queries, feel free to **contact us**! We are here to help!	f	\N	["blog_articles.txt", "products_women_wellness.txt", "products_sexual_health.txt"]	\N
83	stress_test_5	2025-12-11 10:29:45.132567	Do you have any discounts? (no changes needed)	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	safety_redirect	\N	\N
84	stress_test_7	2025-12-11 10:29:47.541258	What is the price of Tes-Up? (no changes needed)	The price of [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) is Rs. 1,031 (discounted from Rs. 1,099 - 6% off). \n\nYou can check it out here: [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule).\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_sexual_health.txt", "products_general_wellness.txt", "blog_articles.txt"]	\N
85	stress_test_6	2025-12-11 10:29:48.625194	How to use Lift-Up Capsules?	To use [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules), follow these instructions:\n\n- **Dosage:** Take 1-2 capsules twice daily.\n- **Best Time:** Consume the capsules with lukewarm water or milk.\n- **Timing:** Take them 30 minutes after meals for optimal absorption.\n- **Recommended Duration:** For best results, it's advised to use the capsules for at least 2-3 months.\n\nYou can find more details and purchase the Lift-Up Capsules here: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules).\n\nIf you have any other questions or need assistance, feel free to contact us!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
86	stress_test_9	2025-12-11 10:29:48.746515	How can I place an order? (no changes needed)	Placing an order with us at Nature Mania is simple! Just follow these steps:\n\n1. Visit our website: [Nature Mania](https://naturemania.in/).\n2. Browse our products and click on any item you're interested in.\n3. Choose the desired quantity and click on the "Add to Cart" button.\n4. Once you've added all your desired products to your cart, click on the cart icon to review your selections.\n5. Click on the "Checkout" button.\n6. Fill in your shipping details and choose your payment method (we offer Cash on Delivery and prepaid options).\n7. Confirm your order.\n\nThat's it! You will receive an order confirmation via email. If you have any further questions or need assistance, please feel free to contact us at [Contact Us](https://naturemania.in/pages/contact) or call 75092-76000. Happy shopping!	f	\N	["naturemania_company.txt", "products_lift_up.txt", "blog_articles.txt"]	\N
87	stress_test_8	2025-12-11 10:29:50.966476	Tell me about Cup-Up Capsules	[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules) are our natural breast enhancement supplement designed to safely and effectively increase breast size without the need for surgery or hazardous medications.\n\n**Price:** Rs. 843 (was Rs. 899 - 6% off!)  \n**Size:** 60 capsules\n\n### Key Benefits:\n- Increases breast size naturally\n- Helps in breast toning and firming\n- Provides plumping, firming, and uplifting effects on breasts\n- Improves cup size and smoothens skin\n- Tightens and improves shape\n- Balances uneven breasts\n- Supports hormonal balance\n- Made with 100% Ayurvedic ingredients and AYUSH certified\n\n### Key Ingredients:\n- Ashwagandha\n- Gambhari\n- Motha\n- Shatawar (Shatavari)\n- Methi\n\n### How to Use:\nTake one capsule in the morning and one in the evening with lukewarm water after 20 minutes of a meal. For best results, we recommend using it continuously for 60-90 days.\n\n### Customer Reviews:\nOur customers have shared positive experiences with Cup-Up Capsules, noting enhancements in both wellness and appearance.\n\nExplore more and order here: [Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)\n\n**Remember:** We offer **Extra 5% Off on Prepaid Orders** and **Free Shipping across India!**	f	\N	["products_women_wellness.txt", "products_lift_up.txt", "products_sexual_health.txt"]	\N
89	stress_test_12	2025-12-11 10:29:58.650362	What are the ingredients in Lift-Up Oil? (no changes needed)	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is made with a blend of natural Ayurvedic ingredients, including:\n\n- Ashwagandha\n- Safed Musli\n- Shatavari\n- Other Ayurvedic herbs\n\nThese ingredients are designed to promote blood circulation and support natural enhancement. You can learn more about Lift-Up Oil and its benefits here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).\n\nIf you have any further questions, feel free to ask!	f	\N	["products_lift_up.txt", "products_general_wellness.txt"]	\N
92	stress_test_14	2025-12-11 10:30:00.228289	What is Smart Shaping Powder used for? (no changes needed)	[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder) is used for effective fat metabolism, increased energy, and improved endurance. It is enriched with L-carnitine compounds, helping to use fat as an energy source for active lifestyles.\n\n**Key Benefits:**\n- Advanced fat metabolism support\n- Boosts energy and endurance\n- Accelerates post-workout recovery\n- Supports brain health and mental clarity\n- Pure, safe, and effective formula\n- No artificial additives or fillers\n\n**Price:** Rs. 2,249 (was Rs. 3,699 - 39% off!)\n\nYou can check it out here: [Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_women_wellness.txt"]	\N
94	stress_test_19	2025-12-11 10:30:08.32248	How to contact customer support? (no changes needed)	You can contact our customer support through the following methods:\n\n**Phone:** 75092-76000  \n**Email:** enquiry@naturemania.in  \n**Contact Page:** [Click here to contact us](https://naturemania.in/pages/contact)\n\nWe're here to help!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_women_wellness.txt"]	\N
97	stress_test_17	2025-12-11 10:30:12.525952	What products help with stamina? (no changes needed)	To boost stamina, we recommend the following Ayurvedic products from our range:\n\n1. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)**: These capsules help boost energy and stamina, enhancing physical performance naturally.\n   - **Price:** Rs. 1,031 (was Rs. 1,099 - 6% off!)\n   - **Product URL:** [Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)\n\n2. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)**: Designed to support natural testosterone levels and improve endurance.\n   - **Price:** Rs. 1,218 (was Rs. 1,299 - 6% off!)\n   - **Product URL:** [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)\n\n3. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)**: A natural massage oil that promotes blood circulation and supports overall vitality and performance.\n   - **Price:** Rs. 999 (was Rs. 1,799 - 44% off!)\n   - **Product URL:** [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\n4. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)**: Known for enhancing endurance and stamina through its rich supply of minerals and fulvic acid.\n   - **Price:** Rs. 1,171 (was Rs. 1,249 - 6% off!)\n   - **Product URL:** [Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\nRegular use of these products, along with a healthy lifestyle, can significantly enhance stamina. \n\nRemember, for personalized health concerns, it's always best to consult a healthcare professional. \n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["blog_articles.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
91	stress_test_10	2025-12-11 10:29:59.795416	What makes Naturemania products different? (no changes needed)	Nature Mania products stand out due to several key factors:\n\n1. **100% Ayurvedic Ingredients**: All our products are formulated using pure Ayurvedic ingredients, ensuring a natural approach to wellness.\n\n2. **AYUSH Certified**: Our products are certified by the AYUSH system, guaranteeing quality and safety.\n\n3. **No Side Effects**: We prioritize safe formulations that do not carry the risk of side effects commonly associated with synthetic products.\n\n4. **Formulated by Experts**: Our product formulations are created by experienced Ayurvedic doctors, ensuring efficacy and alignment with traditional practices.\n\n5. **Comprehensive Wellness Focus**: Our products address a wide range of wellness needs, from intimate health to general well-being, enhancing overall vitality.\n\n6. **Free Shipping and Easy Purchases**: We offer free shipping across India and the convenience of cash on delivery, making it easy for customers to access our products.\n\nIf you want to explore our offerings, feel free to visit: [Nature Mania Products](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
96	stress_test_18	2025-12-11 10:30:11.370583	Tell me about Vit-Up Capsules	[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule) are a comprehensive multivitamin supplement designed to provide optimum nutritional support for overall health. They are formulated with a blend of essential vitamins, minerals, amino acids, and antioxidants.\n\n**Price:** Rs. 1,218 (originally Rs. 1,299 - Save Rs. 81, 6% off)\n**Size:** 60 Capsules\n**Rating:** 4.7 (based on 353 votes)\n\n**Key Benefits:**\n- Boosts the immune system\n- Provides essential nutrients\n- Increases stamina and endurance\n- Improves blood circulation and hormone balance\n- Enhances energy levels\n- Strengthens overall vitality\n\n**Key Ingredients:**\n- Aawla/Amla\n- Ashwagandha\n- Loh Bhasam\n- Vidarikand\n- Shilajit\n- Gokhru\n- Bala\n- Draksha\n- Dalchini\n- Elaichi\n- Abhrak Bhasam\n- Swaran Makshik Bhasam\n- Vidhara Mool\n\n**How to Use:** Take one Vit-Up capsule twice a day with water, after meals. For best results, take them at the same time each day.\n\nCheck out Vit-Up Capsules here: [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)\n\nExtra 5% Off on Prepaid Orders! Free Shipping across India!	f	\N	["products_general_wellness.txt", "products_sexual_health.txt", "blog_articles.txt"]	\N
93	stress_test_16	2025-12-11 10:30:06.62226	Can I pay cash on delivery? (no changes needed)	Yes, you can pay cash on delivery (COD) for your orders with us! We offer this payment option across India. If you have any further questions or need assistance, feel free to contact us.	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N
95	stress_test_15	2025-12-11 10:30:08.473793	How long does delivery take? (no changes needed)	Delivery typically takes 2-6 working days after dispatch. We dispatch orders within 48 hours, ensuring a quick and reliable service. \n\nFor more details or to track your order, you can visit: https://emm-dee-enterprises.shiprocket.co/\n\nIf you have any other questions, feel free to reach out!	f	\N	["naturemania_company.txt", "products_women_wellness.txt", "products_general_wellness.txt"]	\N
98	guest_1765451865245_ikr5yipxx	2025-12-11 11:18:05.563748	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*Here are some products that align with what we discussed:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
99	guest_1765521802876_1s9jl0uvd	2025-12-12 06:43:41.777722	hi	Hi there! We're NIRA, your guide here at Nature Mania. How can we assist you today? Whether you're curious about our Ayurvedic products or need help with something specific, we're here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
100	guest_1765521493208_968l2s3y4	2025-12-12 07:19:00.092941	hi	Hi there! We're NIRA, your guide here at Nature Mania. What brings you here today? If you're looking for information about our Ayurvedic products or need help choosing the right solution, we're happy to assist!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
101	guest_1765532526825_0o345z1jq	2025-12-12 09:42:42.191356	How lift up oil can help me	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is designed to support natural male enhancement by promoting blood circulation and overall vitality. Here are some key benefits:\n\n- **Promotes Blood Circulation**: It enhances blood flow to the male organ, which can improve performance.\n- **Supports Natural Enlargement**: Regular use may help with the natural enlargement process.\n- **Improves Stamina and Performance**: The blend of Ayurvedic herbs is aimed at enhancing stamina and overall energy levels.\n\n**Key Ingredients**: Lift-Up Oil is made from natural Ayurvedic ingredients like Ashwagandha, Safed Musli, and Shatavari, ensuring no harmful additives or chemicals.\n\n**How to Use**: Apply the oil and massage gently for about 10-15 minutes daily for best results.\n\n**Price**: Rs. 999 (originally Rs. 1,799 - 44% off!). \n\nYou can explore more about it here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).\n\nPlus, enjoy **Extra 5% Off on Prepaid Orders** and **Free Shipping** across India! If you have any more questions or need assistance, feel free to reach out to us!	f	\N	["products_lift_up.txt", "blog_articles.txt"]	\N
102	guest_1765532526825_0o345z1jq	2025-12-12 09:43:08.628668	In how many days it will be delivered	Delivery times can vary depending on your location, but we generally aim to deliver our products within 5 to 7 business days. Once your order is placed, you will receive tracking details so you can monitor the shipment.\n\nIf you have specific delivery concerns or need assistance, don’t hesitate to [contact us](https://naturemania.in/pages/contact) or call us at **75092-76000**. We're here to help!	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
103	guest_1765532526825_0o345z1jq	2025-12-12 09:43:34.76336	how can I track my delivery	You can track your delivery easily by visiting our order tracking page here: [Track Order](https://emm-dee-enterprises.shiprocket.co/). Just enter the required details, and you'll be able to see the status of your shipment.\n\nIf you have any further questions or need assistance, feel free to [contact us](https://naturemania.in/pages/contact) or call us at **75092-76000**. We're here to help!	f	\N	["naturemania_company.txt", "products_general_wellness.txt"]	\N
104	guest_1765532526825_0o345z1jq	2025-12-12 09:44:14.143299	is this harmful	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is made with 100% Ayurvedic ingredients and does not contain any harmful additives or chemicals. It is formulated to support natural male enhancement and is designed for external topical application. \n\nThat said, we always recommend doing a patch test before trying any new product on your skin. If you have any specific health concerns or conditions, it's best to consult with a qualified healthcare professional.\n\nFor more details about Lift-Up Oil, check it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil). \n\nIf you have other questions or need assistance, feel free to reach out to us!	f	\N	["products_lift_up.txt", "products_women_wellness.txt", "products_sexual_health.txt"]	\N
105	guest_1765532526825_0o345z1jq	2025-12-12 09:44:46.959035	is it safe with perm up capsule?	Yes, using [Lift-Up Oil](https://naturemania.in/products/lift-up-oil) alongside [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) is considered safe. Both products are formulated with 100% Ayurvedic ingredients and work synergistically to support male enhancement and performance.\n\n- **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** promotes blood circulation and natural enlargement through external application.\n- **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)** help with premature discharge and enhance control during intimacy.\n\nFor optimal results, it's best to use these products consistently. However, if you have specific health concerns or conditions, we always recommend consulting with a qualified healthcare professional.\n\nIf you’d like to know more or have further questions, feel free to reach out to us!	f	\N	["products_lift_up.txt", "products_sexual_health.txt"]	\N
106	guest_1765532526825_0o345z1jq	2025-12-12 09:45:02.736229	hindi me batao	Haan, [Lift-Up Oil](https://naturemania.in/products/lift-up-oil) aur [Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule) ka sath mein istemal karna safe hai. Dono products 100% Ayurvedic ingredients se bane hain aur ye male enhancement aur performance ko support karne ke liye synergistically kaam karte hain.\n\n- **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** blood circulation ko promote karta hai aur external application ke through natural enlargement mein madad karta hai.\n- **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)** premature discharge se bachne aur intimacy ke dauran control badhane mein madad karte hain.\n\nBehtar results ke liye, in products ka istemal regular basis par karna acha rahega. Lekin agar aap ke paas specific health concerns hain, toh hum hamesha recommend karte hain ki ek qualified healthcare professional se sampark karein.\n\nAgar aapko aur information chahiye ya koi aur sawaal hai, toh humse bina jhijhak sampark karein!	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "products_sexual_health.txt"]	\N
107	guest_1765532526825_0o345z1jq	2025-12-12 09:45:32.065893	sperm badhane ke liye konsa product lu?	Sperm badhane ke liye, aap **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** le sakte hain. Ye capsules energy, stamina, aur male vitality ko boost karne ke liye design kiye gaye hain, jo natural enhancement mein madad karte hain.\n\n**Product Details:**\n- **Price:** Rs. 1,499 (pehle Rs. 1,699 - 12% off!)\n- **Size:** 60 capsules\n\n**Key Benefits:**\n- Energy levels ko badhata hai\n- Stamina aur endurance improve karta hai\n- Natural size enhancement ko support karta hai\n- Overall performance ko enhance karta hai\n- 100% Ayurvedic ingredients \n\nIs product ka istemal karne se aapko better results mil sakte hain agar aap ise 2-3 mahine tak regular basis par lete hain.\n\nAgar aapko aur information chahiye, toh yahan dekhein: [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules). \n\nAgar aapke aur sawaal hain, toh humse sampark karein!	f	\N	["products_lift_up.txt", "blog_articles.txt", "products_sexual_health.txt"]	\N
108	guest_1765532526825_0o345z1jq	2025-12-12 09:45:54.84518	is se sar me dard to nahin hoga na ?	Humare **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** mein 100% Ayurvedic ingredients hain, jo generally safe hote hain aur inka koi major side effect nahi hota. Lekin, har vyakti ki body alag hoti hai aur kuch logon ko kisi bhi nayi supplement se pehle sensitivity ho sakti hai.\n\nAgar aapko kisi bhi product ko lene ke baad sar dard ya aur kisi tarah ki samasya mehsoos hoti hai, toh turant product ka istemal band karein aur ek qualified healthcare professional se sampark karen.\n\nAam taur par, [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) ka istemal karne se sar mein dard hona nahi chahiye, lekin agar aapko kisi tarah ki chinta hai, toh hamesha achha hai ki doctor se salah lein. \n\nAgar aapko aur information ki zarurat hai, toh humein batayein!	f	\N	["products_sexual_health.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N
109	guest_1765532526825_0o345z1jq	2025-12-12 09:46:16.571483	isko konsa doctor promote karta hai?	For information about discounts, special offers, or bulk orders, please contact our team directly:\n\n**Phone:** 75092-76000\n**Email:** enquiry@naturemania.in\n\nOur team will be happy to assist you with any pricing inquiries!\n\nIn the meantime, you can also enjoy **Extra 5% Off on Prepaid Orders** on all products. Would you like to know more about any of our products?	t	\N	\N	\N
110	guest_1765532526825_0o345z1jq	2025-12-12 09:46:33.605491	doctor batao	Humare products, jaise ki **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)**, experienced Ayurvedic doctors ke dwara formulate kiye gaye hain. Humara team sirf 100% Ayurvedic ingredients ka hi istemal karta hai, jisse in products ki effectiveness aur safety ka dhyan rakha jata hai.\n\nSpecific doctor ka naam nahi diya gaya hai, lekin humare products ko Ayurvedic doctors ke expertise ke saath banaya gaya hai, jo inki quality aur effectiveness ko ensure karte hain.\n\nAgar aapko kisi particular doctor ke recommendation ya aur kisi detail ki zarurat hai, toh aap hume **[yahan sampark kar sakte hain](https://naturemania.in/pages/contact)** ya **75092-76000** par call kar sakte hain. Hum aapki madad karne ke liye yahan hain!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_sexual_health.txt"]	\N
111	guest_1765533455804_7dcg8qc39	2025-12-12 09:57:45.468904	Hello	Hi there! We're glad to see you here at Nature Mania. What can we assist you with today? Are you looking for information about our Ayurvedic products or do you need help in choosing the right wellness solution?\n\n---\n\n*Feel free to explore more when you're ready:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_lift_up.txt", "naturemania_company.txt", "products_general_wellness.txt"]	\N
112	guest_1765533455804_7dcg8qc39	2025-12-12 09:57:54.737795	who are you	We are NIRA, your friendly assistant here at Nature Mania! Our team specializes in guiding you through our range of Ayurvedic wellness products, helping you find the right solutions for your needs. If you have any questions or need information, feel free to ask! \n\n---\n\n*Explore our products here:*  \n[Shop All](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "products_sexual_health.txt", "products_general_wellness.txt"]	\N
113	guest_1765533455804_7dcg8qc39	2025-12-12 09:58:15.180699	what do you know about ayurveda	Ayurveda is an ancient Indian system of medicine that focuses on holistic health and well-being. It emphasizes the balance between the body, mind, and spirit, utilizing natural herbs, diet, and lifestyle changes to promote wellness. The core principles of Ayurveda include:\n\n1. **Five Elements**: Everything in the universe, including the human body, is made up of five elements: earth, water, fire, air, and ether. These elements combine to form three primary energies or doshas: Vata, Pitta, and Kapha.\n\n2. **Doshas**: Each individual has a unique balance of these doshas, which determines their physical and mental characteristics. Ayurvedic treatments aim to restore balance to these doshas to achieve optimal health.\n\n3. **Natural Remedies**: Ayurveda uses natural ingredients, such as herbs, plants, minerals, and dietary recommendations, to promote healing and prevent disease. \n\n4. **Lifestyle Practices**: Ayurveda encourages a healthy lifestyle that includes proper diet, exercise, yoga, meditation, and stress management to maintain overall well-being.\n\n5. **Personalized Approach**: Ayurveda takes into account each person’s unique constitution, health history, and lifestyle, making the approach highly individualized.\n\nAt Nature Mania, we offer a range of Ayurvedic supplements designed to support various aspects of health and wellness using traditional formulations.\n\nIf you’re interested in exploring any specific Ayurvedic products, let us know!\n\n---\n\n*You can view our products here:*  \n[Shop All](https://naturemania.in/collections/all)	f	\N	["naturemania_company.txt", "products_sexual_health.txt", "products_lift_up.txt"]	\N
114	guest_1765548645708_fhwunxsga	2025-12-12 14:12:12.776551	what products do you sell	We offer a variety of Ayurvedic products that support wellness and enhancement. Here’s a list of our main products:\n\n1. **[Lift-Up Oil](https://naturemania.in/products/lift-up-oil)** (30ml) - Rs. 999 (was Rs. 1,799 - 44% off)  \n   [View Product](https://naturemania.in/products/lift-up-oil)\n\n2. **[Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules)** (60 caps) - Rs. 1,499 (was Rs. 1,699 - 12% off)  \n   [View Product](https://naturemania.in/products/lift-up-capsules)\n\n3. **[Size Combo](https://naturemania.in/products/size-combo)** - Rs. 2,700 (was Rs. 2,998 - 9% off)  \n   [View Product](https://naturemania.in/products/size-combo)\n\n4. **[Perm-Up Capsules](https://naturemania.in/products/perm-up-capsule)** (60 caps) - Rs. 1,312 (was Rs. 1,399 - 6% off)  \n   [View Product](https://naturemania.in/products/perm-up-capsule)\n\n5. **[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule)** (60 caps) - Rs. 1,031 (was Rs. 1,099 - 6% off)  \n   [View Product](https://naturemania.in/products/tes-up-capsule)\n\n6. **[Shilajit Gold Resin](https://naturemania.in/products/nature-mania-shilajit-gold-resin)** (20gm) - Rs. 1,171 (was Rs. 1,249 - 6% off)  \n   [View Product](https://naturemania.in/products/nature-mania-shilajit-gold-resin)\n\n7. **[Cup-Up Capsules](https://naturemania.in/products/cup-up-capsules)** (60 caps) - Rs. 843 (was Rs. 899 - 6% off)  \n   [View Product](https://naturemania.in/products/cup-up-capsules)\n\n8. **[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)** (60 caps) - Rs. 749 (was Rs. 799 - 6% off)  \n   [View Product](https://naturemania.in/products/soothe-up-capsule)\n\n9. **[Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)** (60 caps) - Rs. 1,218 (was Rs. 1,299 - 6% off)  \n   [View Product](https://naturemania.in/products/vit-up-capsule)\n\n10. **[Smart Shaping Powder](https://naturemania.in/products/nature-mania-smart-shaping-powder)** (30 sachets) - Rs. 2,249 (was Rs. 3,699 - 39% off)  \n    [View Product](https://naturemania.in/products/nature-mania-smart-shaping-powder)\n\nYou can check out all of our products [here](https://naturemania.in/collections/all). We also provide **Extra 5% Off on Prepaid Orders** and **Free Shipping across India**! If you have any more questions, feel free to reach out!	f	\N	["naturemania_company.txt", "products_general_wellness.txt", "products_lift_up.txt"]	\N
115	guest_1765548645708_fhwunxsga	2025-12-12 14:12:38.224186	what are the most common problems that your customers come with	We receive inquiries about a variety of wellness concerns from our customers. While we do not provide medical advice, some of the most common topics include:\n\n1. **Intimate Wellness:** Many customers seek products for enhancing male and female intimate wellness, looking for natural solutions to enhance size and performance.\n\n2. **Energy and Stamina:** A significant number of inquiries revolve around boosting energy levels and improving overall stamina and endurance.\n\n3. **Hormonal Balance:** Customers often ask about support for hormonal balance, especially related to women's wellness.\n\n4. **Natural Enhancement:** Many individuals look for natural enhancement solutions, seeking alternatives to surgical procedures.\n\n5. **General Health and Well-Being:** Questions about improving overall vitality and health are common, where customers inquire about natural supplements that can support their lifestyle.\n\nFor specific product recommendations or personalized solutions, feel free to contact us! We’re here to help!\n\n---\n\n*Feel free to explore more when you're ready:*\n[Tes-Up Capsules](https://naturemania.in/products/tes-up-capsule) | [Lift-Up Capsules](https://naturemania.in/products/lift-up-capsules) | [Vit-Up Capsules](https://naturemania.in/products/vit-up-capsule)	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
116	guest_1765548645708_fhwunxsga	2025-12-12 14:17:00.996611	mere raat akele hai. kya karoon	Akele hone par aap kuch activities kar sakte hain jo aapko relax aur entertained rakhengi. Yahan kuch suggestions hain:\n\n1. **Padhai karein:** Aap apne favourite book, article, ya blog padh sakte hain.\n\n2. **Movie ya Series dekhein:** Apne pasand ki movie ya web series dekhna ek accha option hai.\n\n3. **Music suno:** Aap apne favourite songs ya playlists sun sakte hain jo aapko khush karein.\n\n4. **Meditation karein:** Thoda time meditation ya deep breathing exercises mein bhi laga sakte hain, yeh aapko shanti aur relaxation de sakta hai.\n\n5. **Cooking karein:** Agar aapko cooking ka shauk hai, toh naye recipes try karne ka waqt hai!\n\n6. **Writing ya Journaling:** Apne khayalon ko likhna shant kar sakta hai aur aapko clarity de sakta hai.\n\n7. **Online Community se judain:** Social media ya online forums par friends se baat karein ya naye logon se milein.\n\nAgar aap kisi specific samasya ya baat ke liye discuss karna chahte hain, toh aap hamesha humse contact kar sakte hain. Hum yahaan madad karne ke liye hain!\n\n---\n\n*Here are some products that align with what we discussed:*\n[Soothe-Up Capsules](https://naturemania.in/products/soothe-up-capsule)	f	\N	["products_general_wellness.txt", "naturemania_company.txt", "products_sexual_health.txt"]	\N
117	guest_1765603737321_wg66dx7ww	2025-12-13 05:29:42.812884	i want to lift up oil	[Lift-Up Oil](https://naturemania.in/products/lift-up-oil) is our natural men's organ massage oil designed to promote blood circulation and support natural enhancement.\n\n**Price:** Rs. 999 (originally Rs. 1,799 - 44% off!)  \n**Size:** 30ml  \n\n**Key Benefits:**\n- Promotes blood circulation\n- Supports natural enlargement\n- Improves stamina and performance\n- Made with Ayurvedic herbs like Ashwagandha, Safed Musli, and Shatavari\n- 100% Ayurvedic, AYUSH Certified\n\n**How to Use:** Apply the oil and massage gently for 10-15 minutes daily for the best results.\n\nCheck it out here: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil)\n\nDon't forget, we provide **Extra 5% Off on Prepaid Orders** and **Free Shipping across India!**	f	\N	["products_lift_up.txt", "blog_articles.txt"]	\N
118	guest_1765603737321_wg66dx7ww	2025-12-13 05:32:46.938177	how many doctors told about lift-up oil	We don't have specific information about how many doctors recommend [Lift-Up Oil](https://naturemania.in/products/lift-up-oil). However, our Ayurvedic products are designed with natural ingredients and are AYUSH Certified, making them a popular choice for many looking for enhancement solutions. \n\nFor personal health concerns or recommendations regarding our products, we suggest consulting with a qualified healthcare professional. If you need more details about Lift-Up Oil or have any other queries, feel free to ask or you can also [contact us](https://naturemania.in/pages/contact). \n\nHere’s the link to the product for more information: [Lift-Up Oil](https://naturemania.in/products/lift-up-oil).	f	\N	["products_lift_up.txt", "products_women_wellness.txt"]	\N
119	guest_1765604634749_atl3y5g12	2025-12-13 05:44:00.645462	hi	Hi there! I'm NIRA, your guide here at Nature Mania. What brings you here today? Whether you're looking for information about our Ayurvedic products or need help choosing the right solution, I'm happy to help!\n\n---\n\n*If you'd like to learn more, these might interest you:*\n[Shop All](https://naturemania.in/collections/all)	f	\N	["products_general_wellness.txt", "products_women_wellness.txt", "naturemania_company.txt"]	\N
\.


--
-- Data for Name: response_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.response_feedback (id, conversation_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: user_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_accounts (id, channel, external_id, email, display_name, profile_image, created_at, last_seen) FROM stdin;
1	google	test@example.com	test@example.com	Test User	\N	2025-12-04 05:36:09.043215	2025-12-04 05:37:15.246695
2	google	sammy@test.com	sammy@test.com	Sammy Test	\N	2025-12-04 05:57:17.51794	2025-12-04 07:34:48.243748
3	google	newuser@example.com	newuser@example.com	Priya Sharma	\N	2025-12-04 07:35:03.466696	2025-12-04 07:35:03.466701
4	google	test@summary.com	test@summary.com	Test User	\N	2025-12-04 07:53:18.237777	2025-12-04 07:59:12.042548
\.


--
-- Name: analytics_daily_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analytics_daily_id_seq', 1, false);


--
-- Name: chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_sessions_id_seq', 67, true);


--
-- Name: conversation_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_summaries_id_seq', 1, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 119, true);


--
-- Name: response_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.response_feedback_id_seq', 1, false);


--
-- Name: user_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_accounts_id_seq', 4, true);


--
-- Name: analytics_daily analytics_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_daily
    ADD CONSTRAINT analytics_daily_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: conversation_summaries conversation_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_pkey PRIMARY KEY (id);


--
-- Name: conversation_summaries conversation_summaries_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_user_id_key UNIQUE (user_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: response_feedback response_feedback_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_conversation_id_key UNIQUE (conversation_id);


--
-- Name: response_feedback response_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_pkey PRIMARY KEY (id);


--
-- Name: user_accounts uq_channel_external_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT uq_channel_external_id UNIQUE (channel, external_id);


--
-- Name: user_accounts user_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_accounts
    ADD CONSTRAINT user_accounts_pkey PRIMARY KEY (id);


--
-- Name: idx_conversation_summaries_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_summaries_user_id ON public.conversation_summaries USING btree (user_id);


--
-- Name: ix_analytics_daily_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_analytics_daily_date ON public.analytics_daily USING btree (date);


--
-- Name: ix_analytics_daily_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_analytics_daily_id ON public.analytics_daily USING btree (id);


--
-- Name: ix_chat_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_id ON public.chat_sessions USING btree (id);


--
-- Name: ix_chat_sessions_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_chat_sessions_session_id ON public.chat_sessions USING btree (session_id);


--
-- Name: ix_chat_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_sessions_user_id ON public.chat_sessions USING btree (user_id);


--
-- Name: ix_conversations_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_id ON public.conversations USING btree (id);


--
-- Name: ix_conversations_safety_flagged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_safety_flagged ON public.conversations USING btree (safety_flagged);


--
-- Name: ix_conversations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_session_id ON public.conversations USING btree (session_id);


--
-- Name: ix_conversations_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversations_timestamp ON public.conversations USING btree ("timestamp");


--
-- Name: ix_response_feedback_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_response_feedback_id ON public.response_feedback USING btree (id);


--
-- Name: ix_user_accounts_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_channel ON public.user_accounts USING btree (channel);


--
-- Name: ix_user_accounts_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_email ON public.user_accounts USING btree (email);


--
-- Name: ix_user_accounts_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_accounts_external_id ON public.user_accounts USING btree (external_id);


--
-- Name: chat_sessions chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: conversation_summaries conversation_summaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_summaries
    ADD CONSTRAINT conversation_summaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_accounts(id);


--
-- Name: conversations conversations_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_sessions(session_id);


--
-- Name: response_feedback response_feedback_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.response_feedback
    ADD CONSTRAINT response_feedback_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict VRJB0ZGhwwBnVhE5UWr9H2J1AVYjpeABV7oj7qeTixoKcEkN57ttTK5Tf7sccp3

